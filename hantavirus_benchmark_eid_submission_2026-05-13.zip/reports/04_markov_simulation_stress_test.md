# Markov Simulation Stress Test

Status: exploratory appendix method, not validation evidence.

## Purpose

This stress test estimates zero/low/high reported-incidence state transitions from the ECDC seed panel and simulates next-year reported cases. It can help a paper discuss sparse-surveillance uncertainty and scenario sensitivity without pretending synthetic trajectories are ground truth.

## Incidence State Thresholds

| zero_cut | low_high_cut |
| --- | --- |
| 0 | 0.2654 |

## Estimated Transition Matrix

| from_state | zero | low | high |
| --- | --- | --- | --- |
| zero | 0.8947 | 0.05263 | 0.05263 |
| low | 0.06977 | 0.814 | 0.1163 |
| high | 0.04878 | 0.122 | 0.8293 |

## Highest Simulated Probability Of Exceeding Current Cases

| iso3 | country | current_state | median_cases | q05_cases | q95_cases | prob_any_case | prob_above_current |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ROU | Romania | low | 17 | 0 | 826 | 0.9312 | 0.9292 |
| GRC | Greece | low | 9 | 0 | 450 | 0.922 | 0.9216 |
| SVK | Slovakia | high | 229 | 1 | 258 | 0.9512 | 0.8308 |
| SWE | Sweden | high | 448 | 4 | 486 | 0.9556 | 0.8308 |
| SVN | Slovenia | high | 89 | 0 | 106 | 0.9342 | 0.8302 |
| FRA | France | low | 60 | 0 | 2945 | 0.922 | 0.8294 |
| EST | Estonia | high | 57 | 0 | 71 | 0.9078 | 0.8288 |
| LUX | Luxembourg | high | 27 | 0 | 38 | 0.8798 | 0.8266 |
| DEU | Germany | high | 3564 | 53.95 | 3674 | 0.951 | 0.8256 |
| AUT | Austria | high | 387 | 0 | 424 | 0.9464 | 0.8246 |

## Manuscript Use

- Use as a robustness/simulation appendix for reported-incidence state persistence.
- Do not use it to inflate sample size or claim prospective outbreak prediction.
- Pair it with the empirical baseline results and clearly label all outputs as simulated.
