# IJHG Map Figure Notes

Status: generated static country-level geospatial figures for the ECDC-only manuscript path.

## Methods

- Boundaries: Natural Earth 1:50m Admin 0 countries.
- Projection: ETRS89 / LAEA Europe (`EPSG:3035`).
- Unit of analysis: country-year; fills are country-level only.
- Palettes: `viridis`, `cividis`, and Okabe-Ito categorical colors for colorblind-safe rendering.
- Primary prediction map uses the best 2023 feature-ablation model by mean WIS: `land_use`.

## Generated Figures

- `figures/ijhg_incidence_choropleth_2023.png`
- `figures/ijhg_surveillance_completeness_2023.png`
- `figures/ijhg_predicted_observed_incidence_2023.png`
- `figures/ijhg_uncertainty_interval_width_2023.png`

## Caption Guardrail

Captions should state that maps show country-level reported incidence and model uncertainty; they should not imply within-country spatial precision.
