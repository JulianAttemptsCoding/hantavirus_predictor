# International Baseline Report

Status: first reproducible ECDC seed benchmark.

The current benchmark uses ECDC country-year reported hantavirus infection rows for 2019-2023. It is sufficient to verify the modeling and QA pipeline, but not yet sufficient for final publication claims about global generalisation.

## Split

- Training history: all years before each target year.
- Validation target: 2022.
- Test target: 2023.

## Metrics

| target_year | model | n | mean_observed | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | poisson_deviance | brier_any_case |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022 | country_historical_mean_rate | 29 | 75.34 | 65.58 | 0.8703 | 0.6207 | 21.07 | 69.79 | 98.5 | 0.02546 |
| 2022 | empirical_negative_binomial_rate | 29 | 75.34 | 47.17 | 0.6261 | 1 | 694.2 | 72.1 | 98.5 | 0.1584 |
| 2022 | gradient_boosting_rate | 29 | 75.34 | 92.31 | 1.225 | 0 | 0 | 92.31 | 168.3 | 0.2787 |
| 2022 | hierarchical_negative_binomial_rate | 29 | 75.34 | 47.38 | 0.6289 | 1 | 693.5 | 72.79 | 147.9 | 0.1977 |
| 2022 | last_observed_country_rate | 29 | 75.34 | 101.5 | 1.347 | 0.5517 | 24.55 | 108.1 | 158.9 | 0.03334 |
| 2022 | region_syndrome_mean_rate | 29 | 75.34 | 154.9 | 2.055 | 0.1379 | 29.52 | 163.3 | 425.7 | 0.3087 |
| 2023 | country_historical_mean_rate | 28 | 67.32 | 52.47 | 0.7794 | 0.5357 | 20.61 | 58.14 | 41.3 | 0.03644 |
| 2023 | empirical_negative_binomial_rate | 28 | 67.32 | 43.75 | 0.6499 | 1 | 660 | 65.25 | 41.3 | 0.1899 |
| 2023 | gradient_boosting_rate | 28 | 67.32 | 49.65 | 0.7375 | 0 | 4.758e-17 | 49.65 | 65.83 | 0.1796 |
| 2023 | hierarchical_negative_binomial_rate | 28 | 67.32 | 43.9 | 0.652 | 1 | 659.4 | 65.75 | 61.87 | 0.2146 |
| 2023 | last_observed_country_rate | 28 | 67.32 | 42.86 | 0.6366 | 0.5714 | 14.61 | 47.11 | 44.7 | 0.06055 |
| 2023 | region_syndrome_mean_rate | 28 | 67.32 | 116 | 1.723 | 0.1071 | 28.86 | 124.4 | 268.5 | 0.2866 |

## Best Model By Year

| target_year | model | n | mean_observed | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | poisson_deviance | brier_any_case |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022 | empirical_negative_binomial_rate | 29 | 75.34 | 47.17 | 0.6261 | 1 | 694.2 | 72.1 | 98.5 | 0.1584 |
| 2023 | last_observed_country_rate | 28 | 67.32 | 42.86 | 0.6366 | 0.5714 | 14.61 | 47.11 | 44.7 | 0.06055 |

## QA Notes

- Forecasts are quantile forecasts at 0.05, 0.50, and 0.95.
- WIS uses the central 90 percent interval.
- Brier score is evaluated for the pre-registered any-case threshold.
- Negative results should be retained; the strongest simple baseline is the bar to beat.
