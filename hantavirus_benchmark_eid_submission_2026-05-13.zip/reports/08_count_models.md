# Penalized Count Model Report

Status: exploratory penalized Poisson GLM with population offset.

## Model

- Offset: `log(population / 100000)`.
- Penalty: ridge penalty on non-intercept coefficients.
- Hyperparameter selection: 2022 validation WIS.
- Test target: 2023.
- Coefficients are not interpreted causally.

## 2023 Metrics

| target_year | feature_set | model | alpha | n | mean_observed | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | poisson_deviance | brier_any_case | final_model_features_before_one_hot |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2023 | surveillance_only | penalized_poisson_glm | 0.01 | 28 | 67.32 | 250.7 | 3.723 | 0.3214 | 35.32 | 260.7 | 369.9 | 0.1232 | 7 |
| 2023 | context | penalized_poisson_glm | 0.01 | 28 | 67.32 | 275.8 | 4.097 | 0.3214 | 37.11 | 286.5 | 413.5 | 0.1228 | 10 |
| 2023 | land_use | penalized_poisson_glm | 0.01 | 28 | 67.32 | 159.4 | 2.367 | 0.3214 | 28.82 | 167.6 | 200.1 | 0.09899 | 15 |
| 2023 | climate | penalized_poisson_glm | 10 | 28 | 67.32 | 274.6 | 4.078 | 0.25 | 35.5 | 285 | 406.6 | 0.1388 | 20 |
| 2023 | all_public | penalized_poisson_glm | 10 | 28 | 67.32 | 262.8 | 3.903 | 0.2143 | 35.14 | 273 | 387.4 | 0.1473 | 21 |

## Best Count Model By WIS

| target_year | feature_set | model | alpha | n | mean_observed | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | poisson_deviance | brier_any_case | final_model_features_before_one_hot |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2023 | land_use | penalized_poisson_glm | 0.01 | 28 | 67.32 | 159.4 | 2.367 | 0.3214 | 28.82 | 167.6 | 200.1 | 0.09899 | 15 |

## Validation Tuning

| feature_set | alpha | validation_mean_wis |
| --- | --- | --- |
| surveillance_only | 0.01 | 128 |
| surveillance_only | 0.1 | 170.6 |
| surveillance_only | 1 | 128.1 |
| surveillance_only | 10 | 129.3 |
| context | 0.01 | 145 |
| context | 0.1 | 145.1 |
| context | 1 | 145.3 |
| context | 10 | 148.2 |
| land_use | 0.01 | 113.2 |
| land_use | 0.1 | 113.3 |
| land_use | 1 | 113.8 |
| land_use | 10 | 118.1 |
| climate | 0.01 | 157.6 |
| climate | 0.1 | 155 |
| climate | 1 | 147.4 |
| climate | 10 | 129.9 |
| all_public | 0.01 | 243 |
| all_public | 0.1 | 240.7 |
| all_public | 1 | 202.4 |
| all_public | 10 | 144 |

## Promotion Rule

Do not promote this model unless it improves WIS or relative WIS over simple baselines without unacceptable coverage loss.
