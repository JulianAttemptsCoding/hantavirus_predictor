# Sensitivity And Detectability Report

Status: ECDC-only sensitivity checks and simulation-based detectability screen.

## Sensitivity Scenarios

- `primary_all_rows`: original ECDC country-year panel.
- `exclude_non_comprehensive_or_unspecified`: removes Belgium 2023, Cyprus 2023, and any future non-comprehensive rows.
- `exclude_2020_2021_training_years`: excludes COVID-era rows where sample size permits.
- The feature-ablation design already includes a 2020-2021 pandemic-period indicator in `surveillance_only` and all nested sets.

## Primary Sensitivity Metrics

| scenario | split | feature_set | n | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | mase_last_observed_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| primary_all_rows | primary_validation_2022 | surveillance_only | 29 | 94.42 | 1.253 | 0.6897 | 298 | 131.8 | 1.219 |
| primary_all_rows | primary_validation_2022 | context | 29 | 94.11 | 1.249 | 0.7241 | 303.1 | 133.9 | 1.239 |
| primary_all_rows | primary_validation_2022 | land_use | 29 | 93.81 | 1.245 | 0.7586 | 305.7 | 134.1 | 1.24 |
| primary_all_rows | primary_validation_2022 | climate | 29 | 75.62 | 1.004 | 0.7586 | 271.6 | 112.5 | 1.04 |
| primary_all_rows | primary_validation_2022 | all_public | 29 | 74.46 | 0.9882 | 0.7586 | 264.9 | 109.9 | 1.016 |
| primary_all_rows | primary_test_2023 | surveillance_only | 28 | 327 | 4.857 | 0.6429 | 314.5 | 370.1 | 7.853 |
| primary_all_rows | primary_test_2023 | context | 28 | 333.1 | 4.947 | 0.6786 | 322.5 | 381.2 | 8.091 |
| primary_all_rows | primary_test_2023 | land_use | 28 | 318.5 | 4.732 | 0.6786 | 325.9 | 367.4 | 7.798 |
| primary_all_rows | primary_test_2023 | climate | 28 | 348.2 | 5.172 | 0.6786 | 293.2 | 395.4 | 8.392 |
| primary_all_rows | primary_test_2023 | all_public | 28 | 331.3 | 4.922 | 0.6429 | 282.8 | 374.7 | 7.952 |
| exclude_non_comprehensive_or_unspecified | primary_validation_2022 | surveillance_only | 29 | 94.42 | 1.253 | 0.6897 | 298 | 131.8 | 1.219 |
| exclude_non_comprehensive_or_unspecified | primary_validation_2022 | context | 29 | 94.11 | 1.249 | 0.7241 | 303.1 | 133.9 | 1.239 |
| exclude_non_comprehensive_or_unspecified | primary_validation_2022 | land_use | 29 | 93.81 | 1.245 | 0.7586 | 305.7 | 134.1 | 1.24 |
| exclude_non_comprehensive_or_unspecified | primary_validation_2022 | climate | 29 | 75.62 | 1.004 | 0.7586 | 271.6 | 112.5 | 1.04 |
| exclude_non_comprehensive_or_unspecified | primary_validation_2022 | all_public | 29 | 74.46 | 0.9882 | 0.7586 | 264.9 | 109.9 | 1.016 |
| exclude_non_comprehensive_or_unspecified | primary_test_2023 | surveillance_only | 26 | 350.8 | 5.107 | 0.6154 | 315.4 | 396.9 | 7.93 |
| exclude_non_comprehensive_or_unspecified | primary_test_2023 | context | 26 | 357 | 5.197 | 0.6538 | 323.2 | 408 | 8.152 |
| exclude_non_comprehensive_or_unspecified | primary_test_2023 | land_use | 26 | 341.6 | 4.973 | 0.6538 | 327.4 | 393.8 | 7.869 |
| exclude_non_comprehensive_or_unspecified | primary_test_2023 | climate | 26 | 374.1 | 5.447 | 0.6538 | 295.7 | 425.4 | 8.5 |
| exclude_non_comprehensive_or_unspecified | primary_test_2023 | all_public | 26 | 355.9 | 5.181 | 0.6154 | 284.6 | 402.8 | 8.049 |
| exclude_2020_2021_training_years | primary_validation_2022 | all_public | 29 | 99.95 | 1.327 | 0.8621 | 760 | 160.5 | 1.777 |
| exclude_2020_2021_training_years | primary_test_2023 | all_public | 28 | 75.85 | 1.127 | 0.8929 | 764 | 131.3 | 2.786 |

## Simulation-Based Detectability

The simulation preserves the observed country-year structure and population offsets, then injects a standardized precipitation effect into simulated count rates. Detectability is the proportion of simulations where a climate-augmented Poisson rate model improves 2023 WIS by at least 5 percent over a simple surveillance-rate model.

| log_rate_effect_per_sd | iterations | mean_relative_wis_improvement | median_relative_wis_improvement | detectability_rate_5pct_wis |
| --- | --- | --- | --- | --- |
| 0 | 50 | 0.06674 | 0.1165 | 0.64 |
| 0.25 | 50 | 0.48 | 0.748 | 0.84 |
| 0.5 | 50 | 0.8578 | 0.8874 | 1 |
| 0.75 | 50 | 0.8694 | 0.8737 | 1 |
| 1 | 50 | 0.8329 | 0.8311 | 1 |

## Interpretation

These simulations are a power screen, not validation evidence. Low detectability supports cautious negative-result language: covariate effects may be undetectable at public country-year scale rather than absent biologically.
