# Publication Readiness Gate

Verdict: PASS for an ECDC-only public-data benchmark manuscript path.

## Criteria

| area | status | evidence |
| --- | --- | --- |
| ECDC source reconciliation | pass | Annual totals match ECDC Table 1 for 2019-2023. |
| Processed analysis table | pass | 142 rows across 5 years. |
| World Bank context | pass | Population, rurality, and GDP are non-missing for all rows. |
| FAOSTAT land use | pass | 142 joined rows. |
| TerraClimate current-year features | pass | 142 joined rows. |
| TerraClimate lag features | pass | 6 lag-1 climate features complete for 114 non-2019 rows. |
| Surveillance metadata flags | pass | ECDC source-quality metadata present; Belgium 2023 and Cyprus 2023 must be handled in sensitivity analyses. |
| Forecast benchmark outputs | pass | 12 metric rows and 1026 quantile rows, including relative WIS and 90 percent interval width. |
| Calibration caution | warn | Coverage is descriptive at this stage and must be discussed rather than hidden. Best-model coverage: 2022: 1.000 (over-wide); 2023: 0.571 (under-covered). |
| Feature ablation outputs | pass | 35 feature-ablation metric rows. |
| Model feature dimensions | pass | 35 screening rows with raw and final feature counts. |
| Sensitivity and power analyses | pass | 87 sensitivity metric rows and 5 detectability rows. |
| Penalized count-model check | pass | 5 penalized count-model metric rows; promote only if calibration and WIS beat simple baselines. |
| IJHG map package | pass | Natural Earth map notes exist with projection and palette details. |
| Simulation appendix | pass | 29 reported-incidence state simulation rows. |
| MODIS vegetation claims | warn | MODIS is manifest-only. A paper can proceed as ECDC + World Bank + FAOSTAT + TerraClimate, but vegetation claims must be removed unless quality-masked MOD13C2 aggregation is implemented. |
| International generalization claims | warn | PAHO and China CDC rows are not extracted. Frame this as an ECDC/EU-EEA public benchmark unless those rows are added with provenance. |

## ECDC Annual Reconciliation

| year | cases | expected_ecdc_total | difference |
| --- | --- | --- | --- |
| 2019 | 4088 | 4088 | 0 |
| 2020 | 1693 | 1693 | 0 |
| 2021 | 4947 | 4947 | 0 |
| 2022 | 2185 | 2185 | 0 |
| 2023 | 1885 | 1885 | 0 |

## Best Baseline By Target Year

| target_year | model | n | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | brier_any_case |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022 | empirical_negative_binomial_rate | 29 | 47.17 | 0.6261 | 1 | 694.2 | 72.1 | 0.1584 |
| 2023 | last_observed_country_rate | 28 | 42.86 | 0.6366 | 0.5714 | 14.61 | 47.11 | 0.06055 |

## Publication Frame That Passes This Gate

- Main claim: an open, uncertainty-calibrated EU/EEA country-year reported-incidence benchmark using free public surveillance, demographic, land-use, and TerraClimate covariates.
- Simulation claim: reported-incidence state stress testing only; not human-to-human spread prediction and not extra validation data.
- Exclusions: no county-level U.S. human prediction, no operational alerting, no vegetation claim until MODIS QA aggregation exists, and no global generalization claim until non-ECDC source systems are added.
