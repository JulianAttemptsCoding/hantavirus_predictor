# International Data Audit

Status: reproducible ECDC seed audit for the international country-year track.

## Source Scope

- Source: ECDC Hantavirus infection - Annual Epidemiological Report for 2023.
- Case rows: EU/EEA country-year rows from ECDC Table 1, 2019-2023.
- Population denominators: World Bank SP.POP.TOTL joined by ISO3 and year.
- Current source system: ECDC only. PAHO/China rows are intentionally not pooled yet.

## Row Counts

| syndrome | source_system | quality_grade | country_year_rows |
| --- | --- | --- | --- |
| hantavirus_infection | ECDC | B | 140 |
| hantavirus_infection | ECDC | C | 2 |

## ECDC Surveillance Metadata Flags

| year | surveillance_completeness | quality_grade | country_year_rows |
| --- | --- | --- | --- |
| 2019 | comprehensive | B | 28 |
| 2020 | comprehensive | B | 28 |
| 2021 | comprehensive | B | 29 |
| 2022 | comprehensive | B | 29 |
| 2023 | comprehensive | B | 26 |
| 2023 | not_comprehensive | C | 1 |
| 2023 | unspecified | C | 1 |

## Source Total Reconciliation

| year | cases | ecdc_reported_total | difference |
| --- | --- | --- | --- |
| 2019 | 4088 | 4088 | 0 |
| 2020 | 1693 | 1693 | 0 |
| 2021 | 4947 | 4947 | 0 |
| 2022 | 2185 | 2185 | 0 |
| 2023 | 1885 | 1885 | 0 |

## Population Denominator Join

- Missing population rows: 0 of 142.
- Incidence is computed as cases / World Bank population * 100,000.

## Missingness

| field | missing_rows | missing_pct |
| --- | --- | --- |
| population | 0 | 0 |
| rural_population_pct | 0 | 0 |
| gdp_per_capita_current_usd | 0 | 0 |
| deaths | 114 | 80.28 |
| faostat_country_area_1000ha | 0 | 0 |
| faostat_land_area_1000ha | 0 | 0 |
| faostat_agricultural_land_1000ha | 0 | 0 |
| faostat_cropland_1000ha | 0 | 0 |
| faostat_forest_land_1000ha | 0 | 0 |
| faostat_perm_meadows_pastures_1000ha | 5 | 3.521 |
| faostat_other_land_1000ha | 0 | 0 |

## Covariate Join Status

| covariate_family | joined | missing_rows |
| --- | --- | --- |
| World Bank population | True | 0 |
| World Bank rurality/GDP | True | 0 |
| TerraClimate | True | 0 |
| MODIS MOD13C2 | False | 142 |
| FAOSTAT land use | True | 0 |

## TerraClimate Lag-1 Per-Variable Missingness

| field | missing_rows | missing_pct |
| --- | --- | --- |
| terraclimate_def_annual_sum_mm_lag1 | 0 | 0 |
| terraclimate_ppt_annual_sum_mm_lag1 | 0 | 0 |
| terraclimate_soil_annual_mean_mm_lag1 | 0 | 0 |
| terraclimate_tmax_annual_mean_c_lag1 | 0 | 0 |
| terraclimate_tmin_annual_mean_c_lag1 | 0 | 0 |
| terraclimate_vpd_annual_mean_kpa_lag1 | 0 | 0 |

## Duplicate Keys

_No rows._

## Frozen Split Proposal

- Train: 2019-2021.
- Validation: 2022.
- Test: 2023.
- Rolling-origin checks: train through 2020 -> test 2021; train through 2021 -> test 2022; train through 2022 -> test 2023.
- Leave-country-out: code path should be exercised now, but publication claims require more years or source systems.

## Limitations Before Manuscript Use

- Deaths are only populated for 2023 because the extracted ECDC country-year table does not provide 2019-2022 country death counts.
- TerraClimate feature columns present: 12.
- MODIS covariates are represented by explicit unjoined flags until quality-masked MOD13C2 aggregation is implemented.
- The current ECDC-only seed table validates the pipeline but is not the final international publication dataset.
