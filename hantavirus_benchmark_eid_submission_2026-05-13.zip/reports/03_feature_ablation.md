# Feature Ablation Report

Status: nested ECDC-only public-feature ablation.

## Design

- Primary training window: 2019-2021.
- Validation target: 2022.
- Test target: 2023.
- Sensitivity: leave-one-year-out splits for 2019-2023.
- Continuous and binary imputation parameters are learned on training rows only.
- Constant, duplicate, high-missingness, and highly correlated predictors are removed before modeling.
- The final feature count is reported before one-hot encoding and separately from the 97-column processed audit table.

## Nested Feature Sets

- `surveillance_only`: lagged country and panel surveillance summaries plus target-year indicators.
- `context`: surveillance plus lagged World Bank rurality and GDP context.
- `land_use`: context plus lagged FAOSTAT land-use shares.
- `climate`: land-use set plus lagged TerraClimate climate and water-balance variables.
- `all_public`: climate set plus public source-quality metadata; these metadata must not be interpreted causally.

## Primary Metrics

| split | target_year | feature_set | n | mean_observed | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | mase_last_observed_rate | poisson_deviance | brier_any_case | raw_candidate_features | final_model_features_before_one_hot |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| primary_validation_2022 | 2022 | all_public | 29 | 75.34 | 74.46 | 0.9882 | 0.7586 | 264.9 | 109.9 | 1.016 | 174 | 0.386 | 33 | 20 |
| primary_validation_2022 | 2022 | climate | 29 | 75.34 | 75.62 | 1.004 | 0.7586 | 271.6 | 112.5 | 1.04 | 179.4 | 0.3686 | 30 | 19 |
| primary_validation_2022 | 2022 | context | 29 | 75.34 | 94.11 | 1.249 | 0.7241 | 303.1 | 133.9 | 1.239 | 224.3 | 0.3489 | 12 | 9 |
| primary_validation_2022 | 2022 | land_use | 29 | 75.34 | 93.81 | 1.245 | 0.7586 | 305.7 | 134.1 | 1.24 | 215.7 | 0.3437 | 18 | 14 |
| primary_validation_2022 | 2022 | surveillance_only | 29 | 75.34 | 94.42 | 1.253 | 0.6897 | 298 | 131.8 | 1.219 | 236.8 | 0.3683 | 8 | 7 |
| primary_test_2023 | 2023 | all_public | 28 | 67.32 | 331.3 | 4.922 | 0.6429 | 282.8 | 374.7 | 7.952 | 608.9 | 0.3046 | 33 | 20 |
| primary_test_2023 | 2023 | climate | 28 | 67.32 | 348.2 | 5.172 | 0.6786 | 293.2 | 395.4 | 8.392 | 649.2 | 0.313 | 30 | 19 |
| primary_test_2023 | 2023 | context | 28 | 67.32 | 333.1 | 4.947 | 0.6786 | 322.5 | 381.2 | 8.091 | 620.1 | 0.2911 | 12 | 9 |
| primary_test_2023 | 2023 | land_use | 28 | 67.32 | 318.5 | 4.732 | 0.6786 | 325.9 | 367.4 | 7.798 | 591.6 | 0.2936 | 18 | 14 |
| primary_test_2023 | 2023 | surveillance_only | 28 | 67.32 | 327 | 4.857 | 0.6429 | 314.5 | 370.1 | 7.853 | 607.5 | 0.2852 | 8 | 7 |

## Best Primary Feature Set By Year

| split | target_year | feature_set | n | mean_observed | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | mase_last_observed_rate | poisson_deviance | brier_any_case | raw_candidate_features | final_model_features_before_one_hot |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| primary_validation_2022 | 2022 | all_public | 29 | 75.34 | 74.46 | 0.9882 | 0.7586 | 264.9 | 109.9 | 1.016 | 174 | 0.386 | 33 | 20 |
| primary_test_2023 | 2023 | land_use | 28 | 67.32 | 318.5 | 4.732 | 0.6786 | 325.9 | 367.4 | 7.798 | 591.6 | 0.2936 | 18 | 14 |

## Primary Feature Counts

| split | feature_set | raw_candidate_features | final_model_features_before_one_hot |
| --- | --- | --- | --- |
| primary_validation_2022 | surveillance_only | 8 | 7 |
| primary_validation_2022 | context | 12 | 9 |
| primary_validation_2022 | land_use | 18 | 14 |
| primary_validation_2022 | climate | 30 | 19 |
| primary_validation_2022 | all_public | 33 | 20 |
| primary_test_2023 | surveillance_only | 8 | 7 |
| primary_test_2023 | context | 12 | 9 |
| primary_test_2023 | land_use | 18 | 14 |
| primary_test_2023 | climate | 30 | 19 |
| primary_test_2023 | all_public | 33 | 20 |

## Calibration

| split | target_year | feature_set | nominal_coverage | empirical_coverage |
| --- | --- | --- | --- | --- |
| primary_validation_2022 | 2022 | surveillance_only | 0.5 | 0.4138 |
| primary_validation_2022 | 2022 | surveillance_only | 0.9 | 0.6897 |
| primary_validation_2022 | 2022 | context | 0.5 | 0.3103 |
| primary_validation_2022 | 2022 | context | 0.9 | 0.7241 |
| primary_validation_2022 | 2022 | land_use | 0.5 | 0.3103 |
| primary_validation_2022 | 2022 | land_use | 0.9 | 0.7586 |
| primary_validation_2022 | 2022 | climate | 0.5 | 0.3448 |
| primary_validation_2022 | 2022 | climate | 0.9 | 0.7586 |
| primary_validation_2022 | 2022 | all_public | 0.5 | 0.3793 |
| primary_validation_2022 | 2022 | all_public | 0.9 | 0.7586 |
| primary_test_2023 | 2023 | surveillance_only | 0.5 | 0.2857 |
| primary_test_2023 | 2023 | surveillance_only | 0.9 | 0.6429 |
| primary_test_2023 | 2023 | context | 0.5 | 0.2143 |
| primary_test_2023 | 2023 | context | 0.9 | 0.6786 |
| primary_test_2023 | 2023 | land_use | 0.5 | 0.2143 |
| primary_test_2023 | 2023 | land_use | 0.9 | 0.6786 |
| primary_test_2023 | 2023 | climate | 0.5 | 0.25 |
| primary_test_2023 | 2023 | climate | 0.9 | 0.6786 |
| primary_test_2023 | 2023 | all_public | 0.5 | 0.2857 |
| primary_test_2023 | 2023 | all_public | 0.9 | 0.6429 |

## Interpretation Guardrails

- A covariate family is not promoted unless WIS or relative WIS improves without unacceptable coverage loss.
- Sparse country-year public surveillance can make negative ablation results publishable when reported honestly.
- Climate, land-use, and source-quality coefficients are not interpreted causally.
