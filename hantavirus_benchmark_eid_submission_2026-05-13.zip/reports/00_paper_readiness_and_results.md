# Paper Readiness And Current Results

## Verdict

Not fully journal-submission-ready yet. The project is now a reproducible ECDC seed benchmark with audited data, first-pass baselines, FAOSTAT land-use covariates, optional TerraClimate country-year aggregation, source manifests for MOD13C2, figures, and an exploratory Markov simulation stress test. It is not ready for final journal submission until MODIS is either implemented or removed from claims, and the manuscript chooses an ECDC-only methods/data frame or adds PAHO/China source systems.

## Current Data Assets

| asset | status | value |
| --- | --- | --- |
| ECDC country-year case rows | ready | 142 |
| World Bank population/rurality/GDP | ready | 142 |
| FAOSTAT land use | ready | 142 |
| TerraClimate country-year covariates | ready | 142 |
| MOD13C2 country-year covariates | manifest only | 0 |

## Annual ECDC Reported Cases

| year | cases | countries_reporting_or_zero |
| --- | --- | --- |
| 2019 | 4088 | 28 |
| 2020 | 1693 | 28 |
| 2021 | 4947 | 29 |
| 2022 | 2185 | 29 |
| 2023 | 1885 | 28 |

## Best Baseline By Evaluation Year

| target_year | model | n | mean_wis | relative_wis_observed_mean | coverage_90 | mean_interval_width_90 | mae | brier_any_case |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022 | empirical_negative_binomial_rate | 29 | 47.17 | 0.6261 | 1 | 694.2 | 72.1 | 0.1584 |
| 2023 | last_observed_country_rate | 28 | 42.86 | 0.6366 | 0.5714 | 14.61 | 47.11 | 0.06055 |

## Markov Simulation Signal

| iso3 | country | current_state | median_cases | q05_cases | q95_cases | prob_any_case | prob_above_current |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ROU | Romania | low | 17 | 0 | 826 | 0.9312 | 0.9292 |
| GRC | Greece | low | 9 | 0 | 450 | 0.922 | 0.9216 |
| SVK | Slovakia | high | 229 | 1 | 258 | 0.9512 | 0.8308 |
| SWE | Sweden | high | 448 | 4 | 486 | 0.9556 | 0.8308 |
| SVN | Slovenia | high | 89 | 0 | 106 | 0.9342 | 0.8302 |

## Go/No-Go For Paper

| criterion | status | note |
| --- | --- | --- |
| Reproducible ECDC data audit | pass | Source totals reconcile exactly for 2019-2023. |
| Baseline benchmark | pass for seed study | Simple baselines run and expose negative/weak ML results. |
| Climate and vegetation covariates | partial pass | TerraClimate is joined when available; MODIS still requires QA-masked aggregation. |
| International generalization | not yet | PAHO and China CDC source-system rows are not yet extracted. |
| Submission-ready manuscript | not yet | Current state supports a methods/data note or pre-analysis scaffold, not final claims. |

## How To Make The Paper Useful

1. Keep the main empirical claim narrow: an open, audited ECDC/EU-EEA country-year reported-incidence benchmark.
2. Use TerraClimate lagged features for climate claims; add MODIS country-year lags only before making vegetation claims.
3. Use the Markov simulation as a scenario stress-test appendix for sparse surveillance dynamics, not as extra validation data.
4. Add PAHO/China CDC only with full provenance and explicit syndrome/source-system strata.
5. Promote complex models only if they beat the best simple baseline under WIS, relative WIS, interval width, and coverage.
