"""Training module."""
